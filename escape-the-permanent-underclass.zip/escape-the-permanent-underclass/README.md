# ESCAPE THE PERMANENT UNDERCLASS · $UNDERCLASS

The site for `$UNDERCLASS` on Solana.
Mint `8SKrQVfmiNsP6K8Wg9amMAM5uQUayoveiawFfpZbgFgn` — launched on stonk.fun, deepest
book on Raydium CLMM against `$ANTHROPIC` pre-stock.

Black, white, and nothing else. One file, no framework, no build step, no bundler,
no backend, no analytics, no cookies.

## Deploy to Vercel

Import this repository and press deploy. Framework preset: **Other**. There is no
build command and no output directory — `vercel.json` sets clean URLs, immutable
caching on `/assets`, and a short security header block. Nothing else is needed.

```
.
├── index.html          the entire site
├── assets/
│   ├── stairs.jpg      hero still — reduced-motion and no-JS fallback
│   ├── og.jpg          1200×630 social card
│   └── mark.png        apple-touch icon
├── vercel.json
├── robots.txt
└── sitemap.xml
```

Point `escapethepermanentunderclass.io` (or whatever domain you settle on) at the
project, then update the three absolute URLs in the `<head>` — `og:image`,
`canonical`, and the `sitemap.xml` loc.

## The staircase

The hero is a `<canvas>`, not a video and not a GIF. The figure is pinned to one
screen position and the staircase advances underneath him, which is the whole
joke rendered as geometry: he is climbing, he is not getting anywhere, and both
are on purpose.

The gait is not a looping sprite. The stance foot is genuinely planted on a tread
and rides it down and outward as the perspective widens; the swing foot lifts,
arcs, and catches the next tread up; a two-bone inverse-kinematics solve places
each knee from the hip and foot positions. That's why it still reads at silhouette
scale — the walk falls out of the geometry rather than out of a tuned sine wave.

Tuning lives at the top of the `scene()` function:

| constant | meaning |
| --- | --- |
| `N` | treads on screen at once |
| `STEP_MS` | milliseconds per tread advance — the walking tempo |
| `T_FIG` | how far down the staircase he stands, 0 = doorway |
| `hF` | figure height as a fraction of canvas height |
| `ease` exponent | how hard the perspective bunches at the vanishing point |

It pauses when scrolled out of view and when the tab is hidden, caps at 2× DPR,
and under `prefers-reduced-motion` it never starts — the source artwork is shown
instead. With JavaScript off, same.

## What's live

| Source | Feeds | Cadence |
| --- | --- | --- |
| `api.dexscreener.com/latest/dex/tokens/{mint}` | price, market cap, liquidity, volume, 1h/6h/24h deltas, trade split, venue count | 30s |
| Public Solana RPC (publicnode → leorpc → mainnet-beta) | circulating supply, mint authority, freeze authority, decimals, token program | 60s |

Liquidity and volume are both summed across all venues, so the turnover figure
divides like against like. RPC calls walk the whole endpoint list before they are
allowed to fail, back off with jitter, and trip a circuit breaker rather than
hammering a dead host. One browser tab owns the polling through a `BroadcastChannel`
lease with a numeric tiebreak — six open tabs make one set of requests, and closing
the leader promotes a follower instead of freezing every tab.

## Degradation ladder

Written before the fetch code, and the reason the page is hard to break:

1. **Everything live** — market data, chain data, animated scene.
2. **DexScreener only** — chain rows read "unverified"; nothing is blanked.
3. **No network** — the countdown, the staircase and every word still work. They
   are a clock and a canvas; they need nothing.
4. **No JavaScript** — the source artwork replaces the canvas, every FAQ panel is
   open, the whole argument is readable.

An "unverified" row never renders as a green tick. Absence of data is not safety.

## Editing

Content lives in plain arrays near the bottom of the script block: `LORE` for the
timeline, `FAQ` for the questions. Copy is in the markup. The palette is six custom
properties at the top of the stylesheet; the display face is Anton, the interface
Archivo, and every number IBM Plex Mono.

`build.sh` concatenates `parts/*` into `index.html` if you'd rather edit in pieces —
`index.html` is the artefact that ships and is safe to edit directly.

## One thing to check before launch

The mechanism section describes the `$ANTHROPIC` pre-stock pairing as **a market
structure, not a distribution**. That is what is verifiable on-chain today: the
token trades against the pre-stock pair, and holders are not being sent anything.
If a real rewards mechanism ships later, that block and the fourth flow step are
the two places to update — and they should only change once the mechanism is live
and auditable.

## Not financial advice

$UNDERCLASS is a memecoin with no intrinsic value, no revenue and no team
obligation. Unaffiliated with @rameerez and escapethepermanentunderclass.com, with
Anthropic, OpenAI, stonk.fun, PreStocks, Jupiter, or anyone quoted on the page.
Quotations are reproduced for commentary and attributed to their source.
